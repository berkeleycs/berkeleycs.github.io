rm -rf assignment8.zip
zip -q -r assignment8.zip *.py *.ipynb submission_logs best_models
