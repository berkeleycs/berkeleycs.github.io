test = {'name': 'q3',
 'points': 10,
 'suites': [{'cases': [{'code': '>>> maxkd(1234, 1)\n'
                                '4\n'
                                '\n'
                                '>>> maxkd(32749, 2)\n'
                                '79\n'
                                '\n'
                                '>>> maxkd(1917, 2)\n'
                                '97\n'
                                '\n'
                                '>>> maxkd(32749, 18)\n'
                                '32749\n'}],
             'scored': True,
             'setup': 'from q3 import *',
             'type': 'doctest'}]}