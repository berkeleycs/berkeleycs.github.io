test = {
  'name': 'ebnf-pycombinator',
  'points': 0,
  'suites': [
    {
        'type': 'concept',
        'cases': [
        {
          'question': r"""
          Which of the following expressions would NOT be parsable according to this BNF?
          """,
          'choices': ['add(1, 2)', 'sub(3, 4)', 'add(sub(1, 2))', 'add()'],
          'answer': 'add()',
        },
        {
          'question': r"""
          Which of these expressions WOULD be parsable according to this BNF?
          """,
          'choices': ['add(a, b)', 'add("a", "b")', 'add(10, 20)', 'All of these'],
          'answer': 'add(10, 20)',
        },
        {
          'question': r"""
          What line of the BNF should we modify to add support for a "div" operation?
          """,
          'choices': ['pycomb_call: func "(" arg ("," arg)* ")"', 'arg: pycomb_call | NUMBER',
          'func: FUNCNAME', 'FUNCNAME: "add" | "mul" | "sub"'],
          'answer': 'FUNCNAME: "add" | "mul" | "sub"',
        },
        {
          'question': r"""
          Which of the following are considered a terminal?
          """,
          'choices': ['pycomb_call', 'arg', 'func', 'FUNCNAME', 'NUMBER', 'both FUNCNAME and NUMBER', 'All of these'],
          'answer': 'both FUNCNAME and NUMBER',
        }
      ]
    }
  ]
}
