test = {
  'name': 'nonlocal_quiz',
  'points': 0,
  'suites': [
    {
    'type': 'concept',
    'cases':[{
      'question': """
        What is the value returned by the function call ba(3)?
        >>> def ba(by):
        ...     def yo(da):
        ...         by += 2
        ...         return by
        ...     return yo(2)
        ...
        >>> ba(3)
        """,
        'choices': [
            '5',
            '2',
            '3',
            'This code will error'
        ],
        'answer': 'This code will error',
        'hidden': False
    },
    {
      'question': """
        What is the value returned by the function call ba(3)?
        >>> def ba(by):
        ...     def yo(da):
        ...         nonlocal by
        ...         by += 2
        ...         return by
        ...     return yo(3)
        ...
        >>> ba(3)  
        """,
        'choices': [
            '5',
            '2',
            '3',
            'This code will error'
        ],
        'answer': '5',
        'hidden': False
    },      
    {
      'question': """
        What is the value returned by the function call ba([1, 2, 3])?
        >>> def ba(by):
        ...     def yo(da):
        ...         by.append(da)
        ...         return by
        ...     return yo(5)
        ...
        >>> ba([1, 2, 3]) 
        """,
        'choices': [
            '[1, 2, 3, 5]',
            '[1, 2, 3]',
            'None',
            'This code will error'
        ],
        'answer': '[1, 2, 3, 5]',
        'hidden': False
        },
        {
      'question': """
        What is the value returned by the function call ba(5)?
        >>> def ba(by):
        ...     def yo(da):
        ...         yoda = by + da
        ...         return yoda
        ...     return yo(5)
        ...
        >>> ba(5)    
        """,
        'choices': [
            '5',
            '10',
            '15',
            'This code will error'
        ],
        'answer': '10',
        'hidden': False
        }]
    }
    ]
}
