test = {
  'name': 'matchmaker',
  'points': 1,
  'suites': [
    {
      'type': 'sqlite',
      'setup': """
      sqlite> .read lab12.sql
      """,
      'cases': [
        {
            'code': r"""
            sqlite> SELECT * FROM matchmaker LIMIT 10;
            dog|Smells like Teen Spirit|blue|yellow
            dog|Smells like Teen Spirit|blue|blue
            dog|Smells like Teen Spirit|blue|yellow
            dog|Smells like Teen Spirit|blue|blue
            dog|Smells like Teen Spirit|blue|black
            dog|All I want for Christmas is you|maroon|purple
            dog|All I want for Christmas is you|maroon|pink
            dog|All I want for Christmas is you|maroon|pink
            dog|All I want for Christmas is you|maroon|green
            dog|All I want for Christmas is you|maroon|red
            """,
          'hidden': False,
          'locked': False
        }
      ],
    }
  ]
}
