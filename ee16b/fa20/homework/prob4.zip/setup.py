import numpy as np;
import matplotlib;
matplotlib.interactive(True); # extremely useful for interactive development in in ipython, draws immediately without waiting for plt.show
import matplotlib.pyplot as plt;
from matplotlib.widgets import Slider, Button, RadioButtons;

var = 5

class RLCSol:
    def __init__(self, params):
      self.parms = params

    def vc_of_t(self, t, initcond): # solution for vc of t given an initial condition
        """
            vc(t) = K1 e^{lambda_1 t} + K2 e^{lambda_1 t}, where:
                lambda1/2 = -alpha +- sqrt(alpha^2 - 4 pi^2 f0^2)
                K1 = vc(0)/(1-lambda1/lambda2)
                K2 = vc(0) - K1
        """
        sqrtterm = np.sqrt(self.parms.alpha**2 - 4 * np.pi**2 * self.parms.f0**2 + 0j);
        if sqrtterm != 0:
            lambda1 = -self.parms.alpha + sqrtterm;
            lambda2 = -self.parms.alpha - sqrtterm;
            K1 = initcond/(1-lambda1/lambda2);
            K2 = initcond - K1;
            retval = np.real(K1*np.exp(lambda1*t) + K2*np.exp(lambda2*t));
        else:
            lambda1 = -self.parms.alpha
            lambda2 = -self.parms.alpha
            K1 = initcond
            K2 = -K1 * lambda1
            retval = np.real(0 + K1*np.exp(lambda1*t) + K2*t*np.exp(lambda1*t));
        return(retval);

    def vcenvelope_of_t(self, t, initcond): # approximate envelope for vc of t given an initial condition
        if 4 * np.pi**2 * self.parms.f0**2 < self.parms.alpha**2:
            sqrtterm = np.sqrt(self.parms.alpha**2 - 4 * np.pi**2 * self.parms.f0**2 + 0j)
            lambda1 = -self.parms.alpha + sqrtterm;
            lambda2 = -self.parms.alpha - sqrtterm;
            K1 = initcond/(1-lambda1/lambda2);
            K2 = initcond - K1;
            retval = np.real(0 + K1*np.exp(lambda1*t) + K2*np.exp(lambda2*t));
        elif 4 * np.pi**2 * self.parms.f0**2 == self.parms.alpha**2:
            lambda1 = -self.parms.alpha
            lambda2 = -self.parms.alpha
            K1 = initcond
            K2 = -K1 * lambda1
            retval = np.real(0 + K1*np.exp(lambda1*t) + K2*t*np.exp(lambda1*t));
        else:
            sqrtterm = 0
            lambda1 = -self.parms.alpha;
            K1 = initcond;
            retval = np.real(K1*np.exp(lambda1*t)); # - lambda1*t*np.exp(lambda1*t)); 
        return(retval);
    # end def HR

    def generate_plots(self, n_cycles, pts_per_cycle, ts):
      self.ts = ts
      vcs = self.vc_of_t(ts, initcond=1); #
      vcenvelope = self.vcenvelope_of_t(ts, initcond=1);

      fig, ax = plt.subplots(); # like MATLAB's figure()
      plt.subplots_adjust(top=0.75); # changes the margins of the plot

      l, = plt.plot(ts, vcs, linewidth=1, color='red', linestyle='-'); # l, makes it a tuple? l of type matplotlib.lines.line2D. this is like the basic matlab plot(...)
      lenv, = plt.plot(ts, vcenvelope, color='green', linewidth=3, linestyle=':'); # l, makes it a tuple? l of type matplotlib.lines.line2D. this is like the basic matlab plot(...)
      plt.grid(color='k', linestyle='-.', linewidth=0.5); # shows the grid
      plt.grid(which='minor', color='k', linestyle=':', linewidth=0.25); # shows the grid
      plt.xlabel('time (seconds)'); # 
      plt.ylabel('vc(t) (Volts)');
      plt.title('vc(t), series RLC circuit');
      plt.ylim([-1,1])
      fig.set_size_inches(6, 4)

      axcolor = 'lightgoldenrodyellow';
      axC = plt.axes([0.15, 0.95, 0.7, 0.03], facecolor=axcolor); # this brings up another set of axes in the same figure, below the previous one. The argumens are    presumably xstart, ystart, width, height 
      axR = plt.axes([0.15, 0.9, 0.7, 0.03], facecolor=axcolor); # 

      Cmin = self.parms.C/3;
      Cmax = 3*self.parms.C;
      N_C = 100000;
      sC = Slider(axC, 'C', Cmin, Cmax, valinit=self.parms.C, valstep=(Cmax-Cmin)/N_C); # this turns sC into a slider. The args are the range. The 'C' is a label

      Rmin = 1e-2;
      Rmax = 2e4;
      N_R = 1000000;
      sR = Slider(axR, 'log(R)', np.log10(Rmin), np.log10(Rmax), valinit=np.log10(self.parms.R), valstep=(np.log10(Rmax)-np.log10(Rmin))/N_R); # 

      resetax = plt.axes([0.8, 0.8, 0.1, 0.04])

      button = Button(resetax, 'Reset', color=axcolor, hovercolor='0.975')

      def reset(event):
          sR.reset()
          sC.reset()

      button.on_clicked(reset)

      textstr = '\n'.join((
          r'C=%g' % (self.parms.C, ),
          r'R=%g' % (self.parms.R, ) ));

      props = dict(boxstyle='round', facecolor='wheat', alpha=0.5);
      textH = plt.text(0.0, 1.2, textstr, transform=ax.transAxes, fontsize=14,
              verticalalignment='top', bbox=props);

      fig2, e_val_ax = plt.subplots()
      radical = 0.5*np.sqrt((self.parms.R/self.parms.L)**2-4/(self.parms.L*self.parms.C)+0j)
      e_val_1 = -0.5*self.parms.R/self.parms.L+radical
      e_val_2 = -0.5*self.parms.R/self.parms.L-radical

      e_val_lines, = e_val_ax.plot([np.real(e_val_1), np.real(e_val_2)], [np.imag(e_val_1), np.imag(e_val_2)], 'bo', 
        markersize=12)
      e_val_lines.set_label(r'$\lambda_{1}$ = %.2f + %.2f j' % (np.real(e_val_1), np.imag(e_val_1)))
      e_val_ax.plot([],[], 'bo', markersize=12, label=r'$\lambda_{2}$ = %.2f + %.2f j' % (np.real(e_val_2), np.imag(e_val_2)))

      e_val_ax.set_xlim(-6e7,100)
      e_val_ax.set_ylim(-3e6,3e6)
      e_val_ax.set_xlabel("Real")
      e_val_ax.set_ylabel("Imag")
      e_val_ax.set_title("Eigenvalues")
      e_val_ax.ticklabel_format(style='sci', axis='both', scilimits=(0,0))
      e_val_ax.grid(True,which='major',linestyle='--')
      e_val_legend = e_val_ax.legend(loc='upper left')
      fig2.set_size_inches(6, 4)

      def update(val): # function to update the sliding f marker
          C = sC.val;
          logR = sR.val;
          R = 10**logR;

          self.parms.R = R;
          self.parms.C = C;
          self.parms.tauC = self.parms.R*self.parms.C;
          self.parms.tauL = self.parms.L/self.parms.R;
          self.parms.alpha = self.parms.R/(2*self.parms.L);
          self.parms.f0 = 1/(2*np.pi*np.sqrt(self.parms.L*self.parms.C));

          vcs = self.vc_of_t(self.ts, 1);
          vcenvelope = self.vcenvelope_of_t(self.ts,1);
          
          radical = 0.5*np.sqrt((R/self.parms.L)**2-4/(self.parms.L*C)+0j)
          e_val_1 = -0.5*R/self.parms.L+radical
          e_val_2 = -0.5*R/self.parms.L-radical

          l.set_ydata(vcs);
          lenv.set_ydata(vcenvelope)
          e_val_lines.set_xdata([np.real(e_val_1),np.real(e_val_2)])
          e_val_lines.set_ydata([np.imag(e_val_1),np.imag(e_val_2)])
          e_val_legend.get_texts()[0].set_text(r'$\lambda_{1}$ = %.2f + %.2f j' % (np.real(e_val_1), np.imag(e_val_1)))
          e_val_legend.get_texts()[1].set_text(r'$\lambda_{2}$ = %.2f + %.2f j' % (np.real(e_val_2), np.imag(e_val_2)))

          textstr = '\n'.join((
              r'C=%g' % (self.parms.C, ),
              r'R=%g' % (self.parms.R, ),))
          textH.set_text(textstr);

      sC.on_changed(update); # attaching the update function to changes in sfreq slider
      sR.on_changed(update); # attaching the update function to changes in sR slider
      
      plt.show()

      return sR, sC, button